import React, { useState, useRef, useEffect } from 'react';
import { useBrowser } from '@/lib/browserContext';

const AIChat: React.FC = () => {
  const { 
    isChatOpen, 
    setIsChatOpen, 
    chatMessages, 
    sendChatMessage 
  } = useBrowser();
  
  const [inputMessage, setInputMessage] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatMessages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;
    
    await sendChatMessage(inputMessage);
    setInputMessage('');
  };

  const handleCloseChat = () => {
    setIsChatOpen(false);
  };

  if (!isChatOpen) return null;

  return (
    <div className="fixed top-0 right-0 w-80 h-full bg-white border-l border-neutral-200 shadow-lg z-50 flex flex-col">
      {/* Chat Header */}
      <div className="bg-primary text-white p-3 flex items-center justify-between">
        <div className="flex items-center">
          <i className="fas fa-robot mr-2"></i>
          <h3 className="font-semibold">AI Assistant</h3>
        </div>
        <button 
          onClick={handleCloseChat}
          className="p-1 hover:bg-primary/80 rounded transition"
        >
          <i className="fas fa-times"></i>
        </button>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3">
        {chatMessages.length === 0 ? (
          <div className="text-center text-neutral-500 mt-8">
            <i className="fas fa-robot text-3xl mb-3 text-neutral-300"></i>
            <p>Hello! I'm your AI assistant.</p>
            <p className="text-sm mt-1">How can I help you with browsing today?</p>
          </div>
        ) : (
          chatMessages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[70%] p-3 rounded-lg ${
                  message.isUser
                    ? 'bg-primary text-white rounded-br-sm'
                    : 'bg-neutral-100 text-neutral-800 rounded-bl-sm'
                }`}
              >
                <p className="text-sm">{message.text}</p>
                <p className="text-xs mt-1 opacity-70">
                  {message.timestamp.toLocaleTimeString()}
                </p>
              </div>
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Chat Input */}
      <div className="border-t border-neutral-200 p-3">
        <form onSubmit={handleSendMessage} className="flex space-x-2">
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            placeholder="Ask me anything..."
            className="flex-1 px-3 py-2 border border-neutral-300 rounded-lg focus:outline-none focus:border-primary text-sm"
          />
          <button
            type="submit"
            disabled={!inputMessage.trim()}
            className="px-3 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed transition"
          >
            <i className="fas fa-paper-plane"></i>
          </button>
        </form>
      </div>
    </div>
  );
};

export default AIChat;