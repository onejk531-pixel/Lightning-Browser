import React from 'react';

interface StatusBarProps {
  isSecure: boolean;
  domain: string;
  isLoading: boolean;
}

const StatusBar: React.FC<StatusBarProps> = ({ isSecure, domain, isLoading }) => {
  // Generate a random load time between 50-200ms for demonstration
  const loadTime = React.useMemo(() => Math.floor(Math.random() * 150) + 50, [domain]);

  return (
    <div className="py-0.5 px-3 bg-neutral-100 border-t border-neutral-200 flex justify-between items-center text-xs text-neutral-500">
      <div className="flex items-center">
        {isSecure ? (
          <span className="flex items-center mr-3">
            <i className="fas fa-lock text-success text-xs mr-1"></i> Secure
          </span>
        ) : (
          <span className="flex items-center mr-3">
            <i className="fas fa-unlock text-warning text-xs mr-1"></i> Not Secure
          </span>
        )}
        <span>{domain || 'No domain'}</span>
      </div>
      <div>
        {isLoading ? (
          <span className="mr-3"><i className="fas fa-circle-notch fa-spin mr-1"></i> Loading...</span>
        ) : (
          <>
            <span className="mr-3"><i className="fas fa-check-circle mr-1"></i> Up to date</span>
            <span><i className="fas fa-bolt mr-1"></i> {loadTime}ms</span>
          </>
        )}
      </div>
    </div>
  );
};

export default StatusBar;
