import React from 'react';
import { Tab } from '@/lib/browserContext';

interface HeaderProps {
  tabs: Tab[];
  activeTab: Tab | undefined;
  onAddTab: () => void;
  onCloseTab: (id: string) => void;
  onSelectTab: (id: string) => void;
  onGoBack: () => void;
  onGoForward: () => void;
  onRefresh: () => void;
  onGoHome: () => void;
  currentUrl: string;
  setCurrentUrl: (url: string) => void;
  onUrlSubmit: (e: React.FormEvent) => void;
  isBookmarked: boolean;
  onToggleBookmark: () => void;
  onSavePage: () => void;
  onOpenAIChat: () => void;
}

const Header: React.FC<HeaderProps> = ({
  tabs,
  activeTab,
  onAddTab,
  onCloseTab,
  onSelectTab,
  onGoBack,
  onGoForward,
  onRefresh,
  onGoHome,
  currentUrl,
  setCurrentUrl,
  onUrlSubmit,
  isBookmarked,
  onToggleBookmark,
  onSavePage,
  onOpenAIChat
}) => {
  const handleCloseTab = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    onCloseTab(id);
  };

  return (
    <header className="bg-neutral-100 border-b border-neutral-200 py-2 px-3 flex flex-col">
      {/* Top Controls Row */}
      <div className="flex items-center mb-2">
        <div className="flex space-x-1 mr-3">
          <button 
            className="p-1.5 rounded hover:bg-neutral-200 transition" 
            title="Back"
            onClick={onGoBack}
            disabled={!activeTab?.canGoBack}
          >
            <i className="fas fa-arrow-left text-neutral-400"></i>
          </button>
          <button 
            className="p-1.5 rounded hover:bg-neutral-200 transition" 
            title="Forward"
            onClick={onGoForward}
            disabled={!activeTab?.canGoForward}
          >
            <i className="fas fa-arrow-right text-neutral-400"></i>
          </button>
          <button 
            className="p-1.5 rounded hover:bg-neutral-200 transition" 
            title="Refresh"
            onClick={onRefresh}
          >
            <i className="fas fa-redo text-neutral-400"></i>
          </button>
          <button 
            className="p-1.5 rounded hover:bg-neutral-200 transition" 
            title="Home"
            onClick={onGoHome}
          >
            <i className="fas fa-home text-neutral-400"></i>
          </button>
        </div>
        
        <form className="flex-1 relative" onSubmit={onUrlSubmit}>
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <i className="fas fa-search text-neutral-400 text-sm"></i>
          </div>
          <input 
            type="text" 
            className="w-full py-1.5 pl-9 pr-12 rounded bg-white border border-neutral-300 hover:border-neutral-400 focus:border-primary focus:outline-none" 
            placeholder="Search or enter address"
            value={currentUrl}
            onChange={(e) => setCurrentUrl(e.target.value)}
          />
          <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
            <button 
              type="button"
              className="p-1 rounded-full hover:bg-neutral-200 transition" 
              title={isBookmarked ? "Remove Bookmark" : "Add Bookmark"}
              onClick={onToggleBookmark}
            >
              <i className={`${isBookmarked ? 'fas' : 'far'} fa-star text-neutral-400`}></i>
            </button>
          </div>
        </form>
        
        <div className="flex ml-3">
          <button 
            className="p-1.5 rounded hover:bg-neutral-200 transition" 
            title="AI Chat Assistant"
            onClick={onOpenAIChat}
          >
            <i className="fas fa-robot text-neutral-400"></i>
          </button>
          <button 
            className="p-1.5 rounded hover:bg-neutral-200 transition" 
            title="Save Page Offline"
            onClick={onSavePage}
          >
            <i className="fas fa-download text-neutral-400"></i>
          </button>
          <button 
            className="p-1.5 rounded hover:bg-neutral-200 transition" 
            title="Menu"
          >
            <i className="fas fa-ellipsis-v text-neutral-400"></i>
          </button>
        </div>
      </div>
      
      {/* Tabs Row */}
      <div className="flex items-center border-t border-neutral-200 pt-1">
        {tabs.map((tab) => (
          <div 
            key={tab.id}
            className={`flex items-center relative py-1 px-3 mr-1 rounded-t-md ${tab.isActive ? 'bg-white tab-active' : 'bg-neutral-100 hover:bg-neutral-200'} cursor-pointer group`}
            onClick={() => onSelectTab(tab.id)}
          >
            {tab.favicon && (
              <img src={tab.favicon} className="w-4 h-4 mr-2" alt="Tab favicon" />
            )}
            <span className="text-sm max-w-[120px] truncate">
              {tab.isLoading ? 'Loading...' : tab.title}
            </span>
            <button 
              className="ml-2 p-0.5 rounded-full hover:bg-neutral-200 opacity-0 group-hover:opacity-100 transition"
              onClick={(e) => handleCloseTab(e, tab.id)}
            >
              <i className="fas fa-times text-xs text-neutral-400"></i>
            </button>
          </div>
        ))}
        
        <button 
          className="p-1 text-neutral-500 hover:bg-neutral-200 rounded-full" 
          title="New Tab"
          onClick={onAddTab}
        >
          <i className="fas fa-plus text-sm"></i>
        </button>
      </div>
    </header>
  );
};

export default Header;
