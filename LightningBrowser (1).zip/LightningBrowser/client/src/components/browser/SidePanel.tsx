import React from 'react';
import { useBrowser } from '@/lib/browserContext';
import { formatBytes, timeAgo } from '@/lib/browserUtils';
import { viewOfflinePage } from '@/lib/offline';

const SidePanel: React.FC = () => {
  const { 
    webApps, 
    desktopApps, 
    bookmarks, 
    offlinePages,
    launchApp, 
    activeSidePanel, 
    setActiveSidePanel,
    removeBookmark,
    removeOfflinePage
  } = useBrowser();

  return (
    <div className="w-56 bg-neutral-100 border-r border-neutral-200 flex flex-col overflow-hidden">
      <div className="p-2 border-b border-neutral-200">
        <div className="flex space-x-1">
          <button className="flex-1 py-1.5 px-2 rounded bg-primary text-white text-sm font-medium">
            Quick Access
          </button>
          <button className="p-1.5 rounded hover:bg-neutral-200 transition" title="Settings">
            <i className="fas fa-cog text-neutral-400"></i>
          </button>
        </div>
      </div>
      
      {/* Tab Navigation */}
      <div className="flex border-b border-neutral-200">
        <button 
          className={`flex-1 py-2 text-xs font-medium ${activeSidePanel === 'apps' ? 'border-b-2 border-primary text-primary' : 'text-neutral-400 hover:text-neutral-500'}`}
          onClick={() => setActiveSidePanel('apps')}
        >
          Apps
        </button>
        <button 
          className={`flex-1 py-2 text-xs font-medium ${activeSidePanel === 'bookmarks' ? 'border-b-2 border-primary text-primary' : 'text-neutral-400 hover:text-neutral-500'}`}
          onClick={() => setActiveSidePanel('bookmarks')}
        >
          Bookmarks
        </button>
        <button 
          className={`flex-1 py-2 text-xs font-medium ${activeSidePanel === 'offline' ? 'border-b-2 border-primary text-primary' : 'text-neutral-400 hover:text-neutral-500'}`}
          onClick={() => setActiveSidePanel('offline')}
        >
          Offline
        </button>
      </div>
      
      {/* Content Area */}
      <div className="flex-1 overflow-y-auto p-3">
        {/* Apps Panel */}
        {activeSidePanel === 'apps' && (
          <div className="grid grid-cols-3 gap-2">
            {/* Web Apps */}
            {webApps.map((app) => (
              <button
                key={app.id}
                className="flex flex-col items-center p-2 rounded hover:bg-neutral-200"
                onClick={() => launchApp(app)}
              >
                {app.icon && app.icon.startsWith('http') ? (
                  <img src={app.icon} className="w-8 h-8 mb-1" alt={app.name} />
                ) : (
                  <div className="w-8 h-8 bg-primary rounded flex items-center justify-center mb-1">
                    <i className={`${app.icon || 'fas fa-globe'} text-white`}></i>
                  </div>
                )}
                <span className="text-xs text-center">{app.name}</span>
              </button>
            ))}
            
            {/* Desktop Apps Section */}
            {desktopApps.length > 0 && (
              <>
                <div className="col-span-3 pt-3 pb-1">
                  <h3 className="text-xs font-semibold text-neutral-500 mb-2">Desktop Apps</h3>
                </div>
                
                {desktopApps.map((app) => (
                  <button
                    key={app.id}
                    className="flex flex-col items-center p-2 rounded hover:bg-neutral-200"
                    onClick={() => launchApp(app)}
                  >
                    <div className={`w-8 h-8 ${
                      app.name === 'Word' ? 'bg-primary' : 
                      app.name === 'Excel' ? 'bg-success' : 
                      app.name === 'PowerPoint' ? 'bg-error' : 
                      app.name === 'Terminal' ? 'bg-gray-700' : 
                      app.name === 'Explorer' ? 'bg-neutral-300' : 
                      'bg-blue-700'
                    } rounded flex items-center justify-center mb-1`}>
                      <i className={`${app.icon || 'fas fa-desktop'} ${
                        app.name === 'Explorer' ? 'text-neutral-700' : 'text-white'
                      }`}></i>
                    </div>
                    <span className="text-xs text-center">{app.name}</span>
                  </button>
                ))}
              </>
            )}
          </div>
        )}
        
        {/* Bookmarks Panel */}
        {activeSidePanel === 'bookmarks' && (
          <div className="space-y-2">
            {bookmarks.length === 0 ? (
              <div className="text-center py-8">
                <div className="text-neutral-400 mb-2">
                  <i className="far fa-star text-3xl"></i>
                </div>
                <p className="text-sm text-neutral-500">No bookmarks yet</p>
                <p className="text-xs text-neutral-400 mt-1">Click the star icon to bookmark pages</p>
              </div>
            ) : (
              bookmarks.map((bookmark) => (
                <div key={bookmark.id} className="group flex items-center justify-between p-2 rounded hover:bg-neutral-200">
                  <div className="flex items-center overflow-hidden">
                    {bookmark.favicon ? (
                      <img src={bookmark.favicon} className="w-4 h-4 mr-2 flex-shrink-0" alt="" />
                    ) : (
                      <i className="far fa-star text-neutral-400 mr-2 flex-shrink-0"></i>
                    )}
                    <span className="text-sm truncate">{bookmark.title}</span>
                  </div>
                  <button 
                    className="ml-2 p-1 rounded opacity-0 group-hover:opacity-100 hover:bg-neutral-300 transition"
                    onClick={() => removeBookmark(bookmark.url)}
                  >
                    <i className="fas fa-times text-xs text-neutral-500"></i>
                  </button>
                </div>
              ))
            )}
          </div>
        )}
        
        {/* Offline Pages Panel */}
        {activeSidePanel === 'offline' && (
          <div>
            <div className="flex justify-between items-center mb-2">
              <h3 className="text-sm font-semibold">Saved Pages</h3>
              {offlinePages.length > 0 && (
                <button className="text-xs text-primary">Manage</button>
              )}
            </div>
            
            {offlinePages.length === 0 ? (
              <div className="text-center py-8">
                <div className="text-neutral-400 mb-2">
                  <i className="fas fa-download text-3xl"></i>
                </div>
                <p className="text-sm text-neutral-500">No saved pages</p>
                <p className="text-xs text-neutral-400 mt-1">Use the download button to save pages for offline viewing</p>
              </div>
            ) : (
              <div className="space-y-2">
                {offlinePages.map((page) => (
                  <div key={page.id} className="group block p-2 rounded hover:bg-neutral-200">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center overflow-hidden">
                        {page.favicon ? (
                          <img src={page.favicon} className="w-4 h-4 mr-2 flex-shrink-0" alt="" />
                        ) : (
                          <i className="fas fa-file text-neutral-400 mr-2 flex-shrink-0"></i>
                        )}
                        <span className="text-sm truncate">{page.title}</span>
                      </div>
                      <button 
                        className="ml-2 p-1 rounded opacity-0 group-hover:opacity-100 hover:bg-neutral-300 transition"
                        onClick={() => removeOfflinePage(page.id)}
                      >
                        <i className="fas fa-times text-xs text-neutral-500"></i>
                      </button>
                    </div>
                    <div className="flex justify-between">
                      <div className="text-xs text-neutral-400">
                        Saved {timeAgo(page.savedAt)}
                      </div>
                      <div className="text-xs text-neutral-400">
                        {formatBytes(page.size * 1024)}
                      </div>
                    </div>
                    <button 
                      className="mt-1 w-full py-1 text-xs text-center text-primary hover:underline"
                      onClick={() => viewOfflinePage(page.content)}
                    >
                      View Offline
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default SidePanel;
