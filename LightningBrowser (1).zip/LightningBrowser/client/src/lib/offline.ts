// Save a web page for offline viewing
export async function savePageOffline(url: string): Promise<string | null> {
  try {
    // Add protocol if missing
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://' + url;
    }
    
    // Fetch the page content
    const response = await fetch(url);
    if (!response.ok) throw new Error(`Failed to fetch ${url}`);
    
    let html = await response.text();
    
    // Simplify the HTML to make it more lightweight for storage
    // This is a basic implementation - a real browser would do
    // more extensive processing to ensure offline functionality
    
    // Modify URLs to be absolute
    html = makeUrlsAbsolute(html, url);
    
    // Remove scripts to reduce size and avoid console errors when viewing offline
    html = removeScripts(html);
    
    return html;
  } catch (error) {
    console.error('Error saving page offline:', error);
    return null;
  }
}

// Make all URLs in the HTML absolute
function makeUrlsAbsolute(html: string, baseUrl: string): string {
  const base = new URL(baseUrl);
  const baseOrigin = base.origin;
  
  // Convert relative URLs to absolute in various attributes
  const modifiedHtml = html
    // Handle href attributes
    .replace(/href=['"](?!https?:\/\/)(?!data:)(?!#)([^'"]+)['"]/g, (match, p1) => {
      if (p1.startsWith('/')) {
        return `href="${baseOrigin}${p1}"`;
      } else {
        return `href="${new URL(p1, baseUrl).href}"`;
      }
    })
    // Handle src attributes
    .replace(/src=['"](?!https?:\/\/)(?!data:)([^'"]+)['"]/g, (match, p1) => {
      if (p1.startsWith('/')) {
        return `src="${baseOrigin}${p1}"`;
      } else {
        return `src="${new URL(p1, baseUrl).href}"`;
      }
    })
    // Handle url() in inline styles
    .replace(/url\(['"]?(?!https?:\/\/)(?!data:)([^'")]+)['"]?\)/g, (match, p1) => {
      if (p1.startsWith('/')) {
        return `url("${baseOrigin}${p1}")`;
      } else {
        return `url("${new URL(p1, baseUrl).href}")`;
      }
    });
  
  return modifiedHtml;
}

// Remove script tags to make the page more lightweight
function removeScripts(html: string): string {
  return html
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '');
}

// Function to view an offline page from storage
export function viewOfflinePage(content: string): void {
  // In a real implementation, this would render the content in an iframe
  // or in the browser content view
  const blob = new Blob([content], { type: 'text/html' });
  const url = URL.createObjectURL(blob);
  
  // For this example, we'll just open it in a new window/tab
  // In a real browser implementation, this would be displayed in the current tab
  window.open(url, '_blank');
}
