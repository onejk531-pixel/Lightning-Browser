import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { queryClient } from './queryClient';
import { apiRequest } from './queryClient';
import { Bookmark, History, OfflinePage, App } from '@shared/schema';
import { getFavicon, getUrlOrigin } from './browserUtils';
import { savePageOffline } from './offline';
import { useToast } from '@/hooks/use-toast';

export interface Tab {
  id: string;
  title: string;
  url: string;
  favicon: string;
  isActive: boolean;
  isLoading: boolean;
  canGoBack: boolean;
  canGoForward: boolean;
}

type TabHistoryEntry = {
  url: string;
  title: string;
};

interface TabHistory {
  [tabId: string]: {
    entries: TabHistoryEntry[];
    currentIndex: number;
  };
}

interface BrowserContextProps {
  // Tabs
  tabs: Tab[];
  activeTab: Tab | undefined;
  addTab: (url?: string) => void;
  closeTab: (id: string) => void;
  selectTab: (id: string) => void;
  updateTabUrl: (id: string, url: string) => void;
  
  // Navigation
  goBack: () => void;
  goForward: () => void;
  refreshPage: () => void;
  goHome: () => void;
  
  // Address Bar
  currentUrl: string;
  setCurrentUrl: (url: string) => void;
  
  // Bookmarks
  bookmarks: Bookmark[];
  isBookmarked: (url: string) => boolean;
  addBookmark: (title: string, url: string, favicon?: string) => Promise<void>;
  removeBookmark: (url: string) => Promise<void>;
  
  // History
  browserHistory: History[];
  addToHistory: (title: string, url: string, favicon?: string) => Promise<void>;
  clearHistory: () => Promise<void>;
  
  // Offline Pages
  offlinePages: OfflinePage[];
  saveOffline: (title: string, url: string, favicon?: string) => Promise<void>;
  removeOfflinePage: (id: number) => Promise<void>;
  
  // Apps
  apps: App[];
  webApps: App[];
  desktopApps: App[];
  launchApp: (app: App) => void;
  
  // UI State
  activeSidePanel: 'apps' | 'bookmarks' | 'offline' | 'chat';
  setActiveSidePanel: (panel: 'apps' | 'bookmarks' | 'offline' | 'chat') => void;
  
  // AI Chat
  isChatOpen: boolean;
  setIsChatOpen: (open: boolean) => void;
  chatMessages: Array<{id: string; text: string; isUser: boolean; timestamp: Date}>;
  sendChatMessage: (message: string) => Promise<void>;
}

const BrowserContext = createContext<BrowserContextProps | undefined>(undefined);

export const BrowserProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { toast } = useToast();

  // Tab State
  const [tabs, setTabs] = useState<Tab[]>([]);
  const [activeTabId, setActiveTabId] = useState<string | null>(null);
  const [tabHistory, setTabHistory] = useState<TabHistory>({});
  
  // Browser State
  const [currentUrl, setCurrentUrl] = useState<string>('');
  const [bookmarks, setBookmarks] = useState<Bookmark[]>([]);
  const [browserHistory, setBrowserHistory] = useState<History[]>([]);
  const [offlinePages, setOfflinePages] = useState<OfflinePage[]>([]);
  const [apps, setApps] = useState<App[]>([]);
  const [activeSidePanel, setActiveSidePanel] = useState<'apps' | 'bookmarks' | 'offline' | 'chat'>('apps');
  
  // Chat State
  const [isChatOpen, setIsChatOpen] = useState<boolean>(false);
  const [chatMessages, setChatMessages] = useState<Array<{id: string; text: string; isUser: boolean; timestamp: Date}>>([]);

  // Computed values
  const activeTab = tabs.find(tab => tab.id === activeTabId);
  const webApps = apps.filter(app => !app.isDesktopApp);
  const desktopApps = apps.filter(app => app.isDesktopApp);

  // Fetch initial data
  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch bookmarks
        const bookmarksData = await queryClient.fetchQuery({
          queryKey: ['/api/bookmarks'],
          queryFn: async () => {
            const response = await fetch('/api/bookmarks', { credentials: 'include' });
            if (!response.ok) throw new Error('Failed to fetch bookmarks');
            return response.json();
          }
        });
        setBookmarks(bookmarksData);
        
        // Fetch history
        const historyData = await queryClient.fetchQuery({
          queryKey: ['/api/history'],
          queryFn: async () => {
            const response = await fetch('/api/history', { credentials: 'include' });
            if (!response.ok) throw new Error('Failed to fetch history');
            return response.json();
          }
        });
        setBrowserHistory(historyData);
        
        // Fetch offline pages
        const offlinePagesData = await queryClient.fetchQuery({
          queryKey: ['/api/offline-pages'],
          queryFn: async () => {
            const response = await fetch('/api/offline-pages', { credentials: 'include' });
            if (!response.ok) throw new Error('Failed to fetch offline pages');
            return response.json();
          }
        });
        setOfflinePages(offlinePagesData);
        
        // Fetch apps
        const appsData = await queryClient.fetchQuery({
          queryKey: ['/api/apps'],
          queryFn: async () => {
            const response = await fetch('/api/apps', { credentials: 'include' });
            if (!response.ok) throw new Error('Failed to fetch apps');
            return response.json();
          }
        });
        setApps(appsData);
        
      } catch (error) {
        console.error('Error fetching initial data:', error);
        toast({
          title: 'Error',
          description: 'Failed to load browser data. Some features may not work correctly.',
          variant: 'destructive',
        });
      }
    };
    
    fetchData();
  }, [toast]);

  // Initialize with at least one tab when loaded
  useEffect(() => {
    if (tabs.length === 0) {
      const initialTab = createNewTab('https://example.com', 'Example Domain');
      setTabs([initialTab]);
      setActiveTabId(initialTab.id);
      setCurrentUrl(initialTab.url);
      
      // Initialize tab history
      setTabHistory({
        [initialTab.id]: {
          entries: [{ url: initialTab.url, title: initialTab.title }],
          currentIndex: 0
        }
      });
    }
  }, [tabs]);

  // Helper to create a new tab object
  const createNewTab = (url = 'about:blank', title = 'New Tab'): Tab => {
    return {
      id: Date.now().toString(),
      title,
      url,
      favicon: getFavicon(url),
      isActive: false,
      isLoading: false,
      canGoBack: false,
      canGoForward: false
    };
  };

  // Tab Management
  const addTab = useCallback((url = 'about:blank') => {
    const newTab = createNewTab(url);
    setTabs(currentTabs => [...currentTabs, { ...newTab, isActive: true }]);
    setTabs(currentTabs => 
      currentTabs.map(tab => ({
        ...tab,
        isActive: tab.id === newTab.id
      }))
    );
    setActiveTabId(newTab.id);
    setCurrentUrl(url);
    
    // Initialize tab history for the new tab
    setTabHistory(current => ({
      ...current,
      [newTab.id]: {
        entries: [{ url, title: 'New Tab' }],
        currentIndex: 0
      }
    }));
  }, []);

  const closeTab = useCallback((id: string) => {
    setTabs(currentTabs => {
      // Don't close if it's the only tab
      if (currentTabs.length <= 1) return currentTabs;
      
      const updatedTabs = currentTabs.filter(tab => tab.id !== id);
      
      // If we're closing the active tab, activate another tab
      if (id === activeTabId) {
        const indexOfClosedTab = currentTabs.findIndex(tab => tab.id === id);
        const nextActiveTab = updatedTabs[Math.min(indexOfClosedTab, updatedTabs.length - 1)];
        if (nextActiveTab) {
          nextActiveTab.isActive = true;
          setActiveTabId(nextActiveTab.id);
          setCurrentUrl(nextActiveTab.url);
        }
      }
      
      return updatedTabs;
    });
    
    // Clean up tab history
    setTabHistory(current => {
      const newHistory = { ...current };
      delete newHistory[id];
      return newHistory;
    });
  }, [activeTabId]);

  const selectTab = useCallback((id: string) => {
    if (id === activeTabId) return;
    
    setTabs(currentTabs => 
      currentTabs.map(tab => ({
        ...tab,
        isActive: tab.id === id
      }))
    );
    
    const tab = tabs.find(tab => tab.id === id);
    if (tab) {
      setActiveTabId(id);
      setCurrentUrl(tab.url);
    }
  }, [activeTabId, tabs]);

  // History functions
  const addToHistory = useCallback(async (title: string, url: string, favicon?: string) => {
    try {
      const response = await apiRequest('POST', '/api/history', {
        title,
        url,
        favicon: favicon || getFavicon(url)
      });
      
      if (!response.ok) throw new Error('Failed to add to history');
      
      const newEntry = await response.json();
      setBrowserHistory(current => [newEntry, ...current]);
    } catch (error) {
      console.error('Error adding to history:', error);
    }
  }, []);

  const updateTabUrl = useCallback((id: string, url: string) => {
    // Normalize URL
    let normalizedUrl = url;
    if (!url.startsWith('http://') && !url.startsWith('https://') && url !== 'about:blank') {
      normalizedUrl = 'https://' + url;
    }
    
    const title = 'Loading...'; // This would be updated when the page loads
    const favicon = getFavicon(normalizedUrl);
    
    setTabs(currentTabs => 
      currentTabs.map(tab => {
        if (tab.id === id) {
          return {
            ...tab,
            url: normalizedUrl,
            title,
            favicon,
            isLoading: true
          };
        }
        return tab;
      })
    );
    
    if (id === activeTabId) {
      setCurrentUrl(normalizedUrl);
    }
    
    // Update tab history
    setTabHistory(current => {
      const tabHist = current[id];
      if (!tabHist) return current;
      
      const newEntries = [...tabHist.entries.slice(0, tabHist.currentIndex + 1), { url: normalizedUrl, title }];
      
      return {
        ...current,
        [id]: {
          entries: newEntries,
          currentIndex: newEntries.length - 1
        }
      };
    });
    
    // Add to browser history
    addToHistory(title, normalizedUrl, favicon);
    
    // Simulate page load complete after a delay
    setTimeout(() => {
      setTabs(currentTabs => 
        currentTabs.map(tab => {
          if (tab.id === id) {
            // Get domain name for the title if it's a new page
            const origin = getUrlOrigin(normalizedUrl);
            const pageTitle = origin || 'New Page';
            
            return {
              ...tab,
              title: pageTitle,
              isLoading: false,
              canGoBack: tabHistory[id]?.currentIndex > 0,
              canGoForward: tabHistory[id]?.currentIndex < (tabHistory[id]?.entries.length - 1) || false
            };
          }
          return tab;
        })
      );
    }, 1000);
  }, [activeTabId, tabHistory]);

  // Navigation functions
  const goBack = useCallback(() => {
    if (!activeTabId) return;
    
    setTabHistory(current => {
      const tabHist = current[activeTabId];
      if (!tabHist || tabHist.currentIndex <= 0) return current;
      
      const newIndex = tabHist.currentIndex - 1;
      const entry = tabHist.entries[newIndex];
      
      // Update tab with previous entry
      setTabs(currentTabs => 
        currentTabs.map(tab => {
          if (tab.id === activeTabId) {
            return {
              ...tab,
              url: entry.url,
              title: entry.title,
              canGoBack: newIndex > 0,
              canGoForward: true
            };
          }
          return tab;
        })
      );
      
      setCurrentUrl(entry.url);
      
      return {
        ...current,
        [activeTabId]: {
          ...tabHist,
          currentIndex: newIndex
        }
      };
    });
  }, [activeTabId]);

  const goForward = useCallback(() => {
    if (!activeTabId) return;
    
    setTabHistory(current => {
      const tabHist = current[activeTabId];
      if (!tabHist || tabHist.currentIndex >= tabHist.entries.length - 1) return current;
      
      const newIndex = tabHist.currentIndex + 1;
      const entry = tabHist.entries[newIndex];
      
      // Update tab with next entry
      setTabs(currentTabs => 
        currentTabs.map(tab => {
          if (tab.id === activeTabId) {
            return {
              ...tab,
              url: entry.url,
              title: entry.title,
              canGoBack: true,
              canGoForward: newIndex < tabHist.entries.length - 1
            };
          }
          return tab;
        })
      );
      
      setCurrentUrl(entry.url);
      
      return {
        ...current,
        [activeTabId]: {
          ...tabHist,
          currentIndex: newIndex
        }
      };
    });
  }, [activeTabId]);

  const refreshPage = useCallback(() => {
    if (!activeTabId) return;
    
    // Simulate a refresh by briefly setting isLoading
    setTabs(currentTabs => 
      currentTabs.map(tab => {
        if (tab.id === activeTabId) {
          return { ...tab, isLoading: true };
        }
        return tab;
      })
    );
    
    // Reset isLoading after a delay
    setTimeout(() => {
      setTabs(currentTabs => 
        currentTabs.map(tab => {
          if (tab.id === activeTabId) {
            return { ...tab, isLoading: false };
          }
          return tab;
        })
      );
    }, 500);
  }, [activeTabId]);

  const goHome = useCallback(() => {
    if (!activeTabId) return;
    updateTabUrl(activeTabId, 'https://example.com');
  }, [activeTabId, updateTabUrl]);

  // Bookmark functions
  const isBookmarked = useCallback((url: string) => {
    return bookmarks.some(bookmark => bookmark.url === url);
  }, [bookmarks]);

  const addBookmark = useCallback(async (title: string, url: string, favicon?: string) => {
    try {
      const response = await apiRequest('POST', '/api/bookmarks', {
        title,
        url,
        favicon: favicon || getFavicon(url)
      });
      
      if (!response.ok) throw new Error('Failed to add bookmark');
      
      const newBookmark = await response.json();
      setBookmarks(current => [...current, newBookmark]);
      
      toast({
        title: 'Bookmark Added',
        description: `"${title}" has been bookmarked.`,
      });
    } catch (error) {
      console.error('Error adding bookmark:', error);
      toast({
        title: 'Error',
        description: 'Failed to add bookmark.',
        variant: 'destructive',
      });
    }
  }, [toast]);

  const removeBookmark = useCallback(async (url: string) => {
    const bookmark = bookmarks.find(b => b.url === url);
    if (!bookmark) return;
    
    try {
      const response = await apiRequest('DELETE', `/api/bookmarks/${bookmark.id}`);
      
      if (!response.ok) throw new Error('Failed to remove bookmark');
      
      setBookmarks(current => current.filter(b => b.id !== bookmark.id));
      
      toast({
        title: 'Bookmark Removed',
        description: `"${bookmark.title}" has been removed from bookmarks.`,
      });
    } catch (error) {
      console.error('Error removing bookmark:', error);
      toast({
        title: 'Error',
        description: 'Failed to remove bookmark.',
        variant: 'destructive',
      });
    }
  }, [bookmarks, toast]);
  
  // History functions
  const clearHistory = useCallback(async () => {
    try {
      const response = await apiRequest('DELETE', '/api/history');
      
      if (!response.ok) throw new Error('Failed to clear history');
      
      setBrowserHistory([]);
      
      toast({
        title: 'History Cleared',
        description: 'Your browsing history has been cleared.',
      });
    } catch (error) {
      console.error('Error clearing history:', error);
      toast({
        title: 'Error',
        description: 'Failed to clear history.',
        variant: 'destructive',
      });
    }
  }, [toast]);

  // Offline Pages functions
  const saveOffline = useCallback(async (title: string, url: string, favicon?: string) => {
    try {
      // Get page content
      const pageContent = await savePageOffline(url);
      if (!pageContent) {
        throw new Error('Failed to fetch page content');
      }
      
      // Calculate size in KB (roughly)
      const size = Math.round(pageContent.length / 1024);
      
      // Save to backend
      const response = await apiRequest('POST', '/api/offline-pages', {
        title,
        url,
        favicon: favicon || getFavicon(url),
        content: pageContent,
        size
      });
      
      if (!response.ok) throw new Error('Failed to save page offline');
      
      const newPage = await response.json();
      setOfflinePages(current => [newPage, ...current]);
      
      toast({
        title: 'Page Saved',
        description: `"${title}" is now available offline.`,
      });
    } catch (error) {
      console.error('Error saving page offline:', error);
      toast({
        title: 'Error',
        description: 'Failed to save page offline.',
        variant: 'destructive',
      });
    }
  }, [toast]);

  const removeOfflinePage = useCallback(async (id: number) => {
    try {
      const response = await apiRequest('DELETE', `/api/offline-pages/${id}`);
      
      if (!response.ok) throw new Error('Failed to remove offline page');
      
      setOfflinePages(current => current.filter(page => page.id !== id));
      
      toast({
        title: 'Page Removed',
        description: 'The offline page has been removed.',
      });
    } catch (error) {
      console.error('Error removing offline page:', error);
      toast({
        title: 'Error',
        description: 'Failed to remove offline page.',
        variant: 'destructive',
      });
    }
  }, [toast]);

  // App functions
  const launchApp = useCallback((app: App) => {
    if (app.isDesktopApp) {
      // In a real environment, we would use Electron or a desktop integration API
      // Since we're in a browser environment, we'll just show a toast
      toast({
        title: 'Desktop App Launch',
        description: `Launching ${app.name}. (Command: ${app.command})`,
      });
    } else {
      // Open web app in a new tab
      const newTab = createNewTab(app.url, app.name);
      setTabs(currentTabs => [
        ...currentTabs.map(tab => ({ ...tab, isActive: false })),
        { ...newTab, isActive: true }
      ]);
      setActiveTabId(newTab.id);
      setCurrentUrl(app.url);
      
      // Initialize tab history for the new tab
      setTabHistory(current => ({
        ...current,
        [newTab.id]: {
          entries: [{ url: app.url, title: app.name }],
          currentIndex: 0
        }
      }));
    }
  }, [toast]);

  // AI Chat functions
  const sendChatMessage = useCallback(async (message: string) => {
    const userMessageId = Date.now().toString();
    const userMessage = {
      id: userMessageId,
      text: message,
      isUser: true,
      timestamp: new Date()
    };
    
    // Add user message immediately
    setChatMessages(current => [...current, userMessage]);
    
    try {
      // Simulate AI response (in a real app, this would call an AI API)
      setTimeout(() => {
        const aiMessage = {
          id: (Date.now() + 1).toString(),
          text: `I understand you said: "${message}". How can I help you with browsing or finding information?`,
          isUser: false,
          timestamp: new Date()
        };
        setChatMessages(current => [...current, aiMessage]);
      }, 1000);
      
    } catch (error) {
      console.error('Error sending chat message:', error);
      toast({
        title: 'Error',
        description: 'Failed to send message to AI assistant.',
        variant: 'destructive',
      });
    }
  }, [toast]);

  // Context value
  const value: BrowserContextProps = {
    // Tabs
    tabs,
    activeTab,
    addTab,
    closeTab,
    selectTab,
    updateTabUrl,
    
    // Navigation
    goBack,
    goForward,
    refreshPage,
    goHome,
    
    // Address Bar
    currentUrl,
    setCurrentUrl,
    
    // Bookmarks
    bookmarks,
    isBookmarked,
    addBookmark,
    removeBookmark,
    
    // History
    browserHistory,
    addToHistory,
    clearHistory,
    
    // Offline Pages
    offlinePages,
    saveOffline,
    removeOfflinePage,
    
    // Apps
    apps,
    webApps,
    desktopApps,
    launchApp,
    
    // UI State
    activeSidePanel,
    setActiveSidePanel,
    
    // AI Chat
    isChatOpen,
    setIsChatOpen,
    chatMessages,
    sendChatMessage
  };

  return (
    <BrowserContext.Provider value={value}>
      {children}
    </BrowserContext.Provider>
  );
};

export const useBrowser = () => {
  const context = useContext(BrowserContext);
  if (context === undefined) {
    throw new Error('useBrowser must be used within a BrowserProvider');
  }
  return context;
};
