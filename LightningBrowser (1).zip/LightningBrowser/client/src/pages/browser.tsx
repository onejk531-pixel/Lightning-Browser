import React from 'react';
import { useBrowser } from '@/lib/browserContext';
import Header from '@/components/browser/Header';
import SidePanel from '@/components/browser/SidePanel';
import Content from '@/components/browser/Content';
import AIChat from '@/components/browser/AIChat';

const Browser: React.FC = () => {
  const { 
    tabs, 
    activeTab, 
    addTab, 
    closeTab,
    selectTab,
    updateTabUrl,
    goBack,
    goForward,
    refreshPage,
    goHome,
    currentUrl,
    setCurrentUrl,
    isBookmarked,
    addBookmark,
    removeBookmark,
    saveOffline,
    setIsChatOpen
  } = useBrowser();

  // Handle URL submission from address bar
  const handleUrlSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (activeTab) {
      updateTabUrl(activeTab.id, currentUrl);
    }
  };

  // Toggle bookmark for current page
  const toggleBookmark = () => {
    if (!activeTab) return;
    
    if (isBookmarked(activeTab.url)) {
      removeBookmark(activeTab.url);
    } else {
      addBookmark(activeTab.title, activeTab.url, activeTab.favicon);
    }
  };

  // Save current page for offline viewing
  const handleSavePage = () => {
    if (!activeTab) return;
    saveOffline(activeTab.title, activeTab.url, activeTab.favicon);
  };

  // Open AI chat
  const handleOpenAIChat = () => {
    setIsChatOpen(true);
  };

  return (
    <div className="bg-white text-neutral-500 h-screen flex flex-col overflow-hidden">
      <Header 
        tabs={tabs}
        activeTab={activeTab}
        onAddTab={addTab}
        onCloseTab={closeTab}
        onSelectTab={selectTab}
        onGoBack={goBack}
        onGoForward={goForward}
        onRefresh={refreshPage}
        onGoHome={goHome}
        currentUrl={currentUrl}
        setCurrentUrl={setCurrentUrl}
        onUrlSubmit={handleUrlSubmit}
        isBookmarked={activeTab ? isBookmarked(activeTab.url) : false}
        onToggleBookmark={toggleBookmark}
        onSavePage={handleSavePage}
        onOpenAIChat={handleOpenAIChat}
      />
      
      <div className="flex flex-1 overflow-hidden">
        <SidePanel />
        <Content />
      </div>
      
      <AIChat />
    </div>
  );
};

export default Browser;
