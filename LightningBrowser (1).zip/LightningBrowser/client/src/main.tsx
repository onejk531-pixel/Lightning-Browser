import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { BrowserProvider } from "./lib/browserContext";

createRoot(document.getElementById("root")!).render(
  <BrowserProvider>
    <App />
  </BrowserProvider>
);
