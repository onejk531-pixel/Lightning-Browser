import { 
  users, type User, type InsertUser,
  bookmarks, type Bookmark, type InsertBookmark,
  history, type History, type InsertHistory,
  offlinePages, type OfflinePage, type InsertOfflinePage,
  apps, type App, type InsertApp
} from "@shared/schema";

// modify the interface with any CRUD methods
// you might need
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Bookmark methods
  getBookmarks(): Promise<Bookmark[]>;
  getBookmark(id: number): Promise<Bookmark | undefined>;
  createBookmark(bookmark: InsertBookmark): Promise<Bookmark>;
  deleteBookmark(id: number): Promise<boolean>;
  
  // History methods
  getHistory(): Promise<History[]>;
  addToHistory(entry: InsertHistory): Promise<History>;
  clearHistory(): Promise<void>;
  
  // Offline pages methods
  getOfflinePages(): Promise<OfflinePage[]>;
  getOfflinePage(id: number): Promise<OfflinePage | undefined>;
  saveOfflinePage(page: InsertOfflinePage): Promise<OfflinePage>;
  deleteOfflinePage(id: number): Promise<boolean>;
  
  // Apps methods
  getApps(): Promise<App[]>;
  createApp(app: InsertApp): Promise<App>;
  updateApp(id: number, app: Partial<InsertApp>): Promise<App | undefined>;
  deleteApp(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private bookmarksMap: Map<number, Bookmark>;
  private historyMap: Map<number, History>;
  private offlinePagesMap: Map<number, OfflinePage>;
  private appsMap: Map<number, App>;
  
  currentUserId: number;
  currentBookmarkId: number;
  currentHistoryId: number;
  currentOfflinePageId: number;
  currentAppId: number;

  constructor() {
    this.users = new Map();
    this.bookmarksMap = new Map();
    this.historyMap = new Map();
    this.offlinePagesMap = new Map();
    this.appsMap = new Map();
    
    this.currentUserId = 1;
    this.currentBookmarkId = 1;
    this.currentHistoryId = 1;
    this.currentOfflinePageId = 1;
    this.currentAppId = 1;
    
    // Add some default apps
    this.initializeDefaultApps();
  }

  // Initialize with default web and desktop apps
  private initializeDefaultApps() {
    const defaultWebApps = [
      { name: "Gmail", url: "https://mail.google.com", icon: "https://mail.google.com/favicon.ico", isDesktopApp: false, order: 1 },
      { name: "YouTube", url: "https://www.youtube.com", icon: "https://www.youtube.com/favicon.ico", isDesktopApp: false, order: 2 },
      { name: "Maps", url: "https://maps.google.com", icon: "https://www.google.com/maps/favicon.ico", isDesktopApp: false, order: 3 },
      { name: "Drive", url: "https://drive.google.com", icon: "https://drive.google.com/favicon.ico", isDesktopApp: false, order: 4 },
      { name: "Twitter", url: "https://twitter.com", icon: "https://twitter.com/favicon.ico", isDesktopApp: false, order: 5 },
      { name: "Dropbox", url: "https://www.dropbox.com", icon: "https://www.dropbox.com/favicon.ico", isDesktopApp: false, order: 6 }
    ];
    
    const defaultDesktopApps = [
      { name: "Word", url: "word", icon: "fas fa-file-word", isDesktopApp: true, command: "start winword.exe", order: 7 },
      { name: "Excel", url: "excel", icon: "fas fa-file-excel", isDesktopApp: true, command: "start excel.exe", order: 8 },
      { name: "PowerPoint", url: "powerpoint", icon: "fas fa-file-powerpoint", isDesktopApp: true, command: "start powerpnt.exe", order: 9 },
      { name: "Terminal", url: "terminal", icon: "fas fa-terminal", isDesktopApp: true, command: "start cmd.exe", order: 10 },
      { name: "Explorer", url: "explorer", icon: "fas fa-folder", isDesktopApp: true, command: "start explorer.exe", order: 11 },
      { name: "Notes", url: "notes", icon: "fas fa-sticky-note", isDesktopApp: true, command: "start notepad.exe", order: 12 }
    ];
    
    [...defaultWebApps, ...defaultDesktopApps].forEach(app => {
      this.createApp(app as InsertApp);
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Bookmark methods
  async getBookmarks(): Promise<Bookmark[]> {
    return Array.from(this.bookmarksMap.values());
  }
  
  async getBookmark(id: number): Promise<Bookmark | undefined> {
    return this.bookmarksMap.get(id);
  }
  
  async createBookmark(insertBookmark: InsertBookmark): Promise<Bookmark> {
    const id = this.currentBookmarkId++;
    const bookmark: Bookmark = { 
      ...insertBookmark, 
      id, 
      createdAt: new Date() 
    };
    this.bookmarksMap.set(id, bookmark);
    return bookmark;
  }
  
  async deleteBookmark(id: number): Promise<boolean> {
    return this.bookmarksMap.delete(id);
  }
  
  // History methods
  async getHistory(): Promise<History[]> {
    return Array.from(this.historyMap.values())
      .sort((a, b) => b.visitedAt.getTime() - a.visitedAt.getTime());
  }
  
  async addToHistory(insertHistory: InsertHistory): Promise<History> {
    const id = this.currentHistoryId++;
    const historyEntry: History = { 
      ...insertHistory, 
      id, 
      visitedAt: new Date() 
    };
    this.historyMap.set(id, historyEntry);
    return historyEntry;
  }
  
  async clearHistory(): Promise<void> {
    this.historyMap.clear();
  }
  
  // Offline pages methods
  async getOfflinePages(): Promise<OfflinePage[]> {
    return Array.from(this.offlinePagesMap.values())
      .sort((a, b) => b.savedAt.getTime() - a.savedAt.getTime());
  }
  
  async getOfflinePage(id: number): Promise<OfflinePage | undefined> {
    return this.offlinePagesMap.get(id);
  }
  
  async saveOfflinePage(insertPage: InsertOfflinePage): Promise<OfflinePage> {
    const id = this.currentOfflinePageId++;
    const page: OfflinePage = { 
      ...insertPage, 
      id, 
      savedAt: new Date() 
    };
    this.offlinePagesMap.set(id, page);
    return page;
  }
  
  async deleteOfflinePage(id: number): Promise<boolean> {
    return this.offlinePagesMap.delete(id);
  }
  
  // Apps methods
  async getApps(): Promise<App[]> {
    return Array.from(this.appsMap.values())
      .sort((a, b) => a.order - b.order);
  }
  
  async createApp(insertApp: InsertApp): Promise<App> {
    const id = this.currentAppId++;
    const app: App = { ...insertApp, id };
    this.appsMap.set(id, app);
    return app;
  }
  
  async updateApp(id: number, updatedFields: Partial<InsertApp>): Promise<App | undefined> {
    const app = this.appsMap.get(id);
    if (!app) return undefined;
    
    const updatedApp = { ...app, ...updatedFields };
    this.appsMap.set(id, updatedApp);
    return updatedApp;
  }
  
  async deleteApp(id: number): Promise<boolean> {
    return this.appsMap.delete(id);
  }
}

export const storage = new MemStorage();
