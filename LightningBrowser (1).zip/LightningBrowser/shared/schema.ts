import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Bookmark schema
export const bookmarks = pgTable("bookmarks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  url: text("url").notNull(),
  favicon: text("favicon"),
  createdAt: timestamp("created_at").notNull().defaultNow()
});

export const insertBookmarkSchema = createInsertSchema(bookmarks).pick({
  title: true,
  url: true,
  favicon: true,
});

export type InsertBookmark = z.infer<typeof insertBookmarkSchema>;
export type Bookmark = typeof bookmarks.$inferSelect;

// History schema
export const history = pgTable("history", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  url: text("url").notNull(),
  favicon: text("favicon"),
  visitedAt: timestamp("visited_at").notNull().defaultNow()
});

export const insertHistorySchema = createInsertSchema(history).pick({
  title: true,
  url: true,
  favicon: true,
});

export type InsertHistory = z.infer<typeof insertHistorySchema>;
export type History = typeof history.$inferSelect;

// Offline page schema
export const offlinePages = pgTable("offline_pages", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  url: text("url").notNull(),
  favicon: text("favicon"),
  content: text("content").notNull(),
  savedAt: timestamp("saved_at").notNull().defaultNow(),
  size: integer("size").notNull()
});

export const insertOfflinePageSchema = createInsertSchema(offlinePages).pick({
  title: true,
  url: true,
  favicon: true,
  content: true,
  size: true,
});

export type InsertOfflinePage = z.infer<typeof insertOfflinePageSchema>;
export type OfflinePage = typeof offlinePages.$inferSelect;

// App schema for quick access
export const apps = pgTable("apps", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  url: text("url").notNull(),
  icon: text("icon"),
  isDesktopApp: boolean("is_desktop_app").default(false),
  command: text("command"),
  order: integer("order").default(0)
});

export const insertAppSchema = createInsertSchema(apps).pick({
  name: true,
  url: true,
  icon: true,
  isDesktopApp: true,
  command: true,
  order: true,
});

export type InsertApp = z.infer<typeof insertAppSchema>;
export type App = typeof apps.$inferSelect;
