# LightningBrowser

A lightweight web browser project built with **Vite**, **TypeScript**, **TailwindCSS**, and **Drizzle ORM**.

---

## 🚀 Features
- Fast, modern frontend powered by Vite.
- Type-safe development with TypeScript.
- Utility-first styling using TailwindCSS.
- Database layer handled by Drizzle ORM.

---

## 🛠️ Development

### Prerequisites
- Node.js (>= 18.x recommended)
- npm or yarn

### Install dependencies
```bash
npm install
# or
yarn install
```

### Run development server
```bash
npm run dev
```

### Build for production
```bash
npm run build
```

### Preview build
```bash
npm run preview
```

---

## 📂 Project Structure
- `src/` – Application source code
- `public/` – Static assets
- `drizzle.config.ts` – Database configuration
- `tailwind.config.ts` – Tailwind settings
- `vite.config.ts` – Vite bundler configuration

---

## 🧑‍💻 Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.
