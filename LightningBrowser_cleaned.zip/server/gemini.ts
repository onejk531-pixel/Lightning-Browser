import { GoogleGenAI } from "@google/genai";

// DON'T DELETE THIS COMMENT - Using the Gemini integration blueprint
// Follow these instructions when using this blueprint:
// - Note that the newest Gemini model series is "gemini-2.5-flash" or "gemini-2.5-pro"
//   - do not change this unless explicitly requested by the user

// Validate API key at startup
if (!process.env.GEMINI_API_KEY) {
  console.error("GEMINI_API_KEY environment variable is required but not provided");
  throw new Error("Missing GEMINI_API_KEY environment variable");
}

// This API key is from Gemini Developer API Key, not vertex AI API Key
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function generateChatResponse(message: string): Promise<string> {
  try {
    const systemPrompt = `You are a helpful AI assistant integrated into a custom web browser. 
You can help users with web browsing, answer questions, provide information, and assist with various tasks.
Keep your responses concise but helpful. Be friendly and conversational.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        systemInstruction: systemPrompt,
      },
      contents: message,
    });

    return response.text || "I'm sorry, I couldn't generate a response at the moment.";
  } catch (error) {
    console.error("Gemini API error:", error);
    
    // Handle specific API errors
    const errorMessage = error instanceof Error ? error.message : String(error);
    if (errorMessage.includes('API key')) {
      return "I'm sorry, there's an issue with my configuration. Please check the API key.";
    } else if (errorMessage.includes('quota') || errorMessage.includes('rate limit')) {
      return "I'm sorry, I'm currently experiencing high usage. Please try again in a moment.";
    } else if (errorMessage.includes('model')) {
      return "I'm sorry, there's an issue with the AI model. Please try again later.";
    }
    
    return "I'm sorry, I'm having trouble connecting to the AI service right now. Please try again later.";
  }
}