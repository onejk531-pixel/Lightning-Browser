import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertBookmarkSchema, 
  insertHistorySchema, 
  insertOfflinePageSchema, 
  insertAppSchema
} from "@shared/schema";
import { z } from "zod";
import { generateChatResponse } from "./gemini";

export async function registerRoutes(app: Express): Promise<Server> {
  // Bookmarks API
  app.get("/api/bookmarks", async (req: Request, res: Response) => {
    try {
      const bookmarks = await storage.getBookmarks();
      res.json(bookmarks);
    } catch (error) {
      res.status(500).json({ message: "Error fetching bookmarks" });
    }
  });
  
  app.post("/api/bookmarks", async (req: Request, res: Response) => {
    try {
      const validatedData = insertBookmarkSchema.parse(req.body);
      const bookmark = await storage.createBookmark(validatedData);
      res.status(201).json(bookmark);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid bookmark data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Error creating bookmark" });
      }
    }
  });
  
  app.delete("/api/bookmarks/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid bookmark ID" });
      }
      
      const success = await storage.deleteBookmark(id);
      if (success) {
        res.status(204).send();
      } else {
        res.status(404).json({ message: "Bookmark not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Error deleting bookmark" });
    }
  });
  
  // History API
  app.get("/api/history", async (req: Request, res: Response) => {
    try {
      const history = await storage.getHistory();
      res.json(history);
    } catch (error) {
      res.status(500).json({ message: "Error fetching history" });
    }
  });
  
  app.post("/api/history", async (req: Request, res: Response) => {
    try {
      const validatedData = insertHistorySchema.parse(req.body);
      const historyEntry = await storage.addToHistory(validatedData);
      res.status(201).json(historyEntry);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid history data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Error adding to history" });
      }
    }
  });
  
  app.delete("/api/history", async (req: Request, res: Response) => {
    try {
      await storage.clearHistory();
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Error clearing history" });
    }
  });
  
  // Offline Pages API
  app.get("/api/offline-pages", async (req: Request, res: Response) => {
    try {
      const offlinePages = await storage.getOfflinePages();
      res.json(offlinePages);
    } catch (error) {
      res.status(500).json({ message: "Error fetching offline pages" });
    }
  });
  
  app.get("/api/offline-pages/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid offline page ID" });
      }
      
      const page = await storage.getOfflinePage(id);
      if (page) {
        res.json(page);
      } else {
        res.status(404).json({ message: "Offline page not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Error fetching offline page" });
    }
  });
  
  app.post("/api/offline-pages", async (req: Request, res: Response) => {
    try {
      const validatedData = insertOfflinePageSchema.parse(req.body);
      const offlinePage = await storage.saveOfflinePage(validatedData);
      res.status(201).json(offlinePage);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid offline page data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Error saving offline page" });
      }
    }
  });
  
  app.delete("/api/offline-pages/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid offline page ID" });
      }
      
      const success = await storage.deleteOfflinePage(id);
      if (success) {
        res.status(204).send();
      } else {
        res.status(404).json({ message: "Offline page not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Error deleting offline page" });
    }
  });
  
  // Apps API
  app.get("/api/apps", async (req: Request, res: Response) => {
    try {
      const apps = await storage.getApps();
      res.json(apps);
    } catch (error) {
      res.status(500).json({ message: "Error fetching apps" });
    }
  });
  
  app.post("/api/apps", async (req: Request, res: Response) => {
    try {
      const validatedData = insertAppSchema.parse(req.body);
      const app = await storage.createApp(validatedData);
      res.status(201).json(app);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid app data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Error creating app" });
      }
    }
  });
  
  app.patch("/api/apps/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid app ID" });
      }
      
      // Partial update, only validate fields that are present
      const partialSchema = insertAppSchema.partial();
      const validatedData = partialSchema.parse(req.body);
      
      const updatedApp = await storage.updateApp(id, validatedData);
      if (updatedApp) {
        res.json(updatedApp);
      } else {
        res.status(404).json({ message: "App not found" });
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid app data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Error updating app" });
      }
    }
  });
  
  app.delete("/api/apps/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid app ID" });
      }
      
      const success = await storage.deleteApp(id);
      if (success) {
        res.status(204).send();
      } else {
        res.status(404).json({ message: "App not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Error deleting app" });
    }
  });

  // Chat API
  const chatMessageSchema = z.object({
    message: z.string().min(1, "Message cannot be empty").max(1000, "Message too long")
  });

  app.post("/api/chat", async (req: Request, res: Response) => {
    try {
      const { message } = chatMessageSchema.parse(req.body);
      const response = await generateChatResponse(message);
      res.json({ response });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid message data", errors: error.errors });
      } else {
        console.error("Chat API error:", error);
        res.status(500).json({ message: "Error generating chat response" });
      }
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
