import React from 'react';
import { Tab as TabType } from '@/lib/browserContext';

interface TabProps {
  tab: TabType;
  onSelect: (id: string) => void;
  onClose: (id: string) => void;
}

const Tab: React.FC<TabProps> = ({ tab, onSelect, onClose }) => {
  const handleClose = (e: React.MouseEvent) => {
    e.stopPropagation();
    onClose(tab.id);
  };

  return (
    <div 
      className={`flex items-center relative py-1 px-3 mr-1 rounded-t-md ${tab.isActive ? 'bg-white tab-active' : 'bg-neutral-100 hover:bg-neutral-200'} cursor-pointer group`}
      onClick={() => onSelect(tab.id)}
    >
      {tab.favicon && (
        <img src={tab.favicon} className="w-4 h-4 mr-2" alt="Tab favicon" />
      )}
      <span className="text-sm max-w-[120px] truncate">
        {tab.isLoading ? 'Loading...' : tab.title}
      </span>
      <button 
        className="ml-2 p-0.5 rounded-full hover:bg-neutral-200 opacity-0 group-hover:opacity-100 transition"
        onClick={handleClose}
      >
        <i className="fas fa-times text-xs text-neutral-400"></i>
      </button>
    </div>
  );
};

export default Tab;
