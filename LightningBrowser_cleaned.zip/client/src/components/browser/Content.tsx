import React from 'react';
import { useBrowser } from '@/lib/browserContext';
import StatusBar from './StatusBar';
import { formatDate } from '@/lib/browserUtils';

const Content: React.FC = () => {
  const { activeTab, saveOffline } = useBrowser();

  const getSecureStatus = (url: string) => {
    if (!url || url === 'about:blank') return false;
    try {
      return new URL(url).protocol === 'https:';
    } catch (error) {
      return false;
    }
  };

  const renderEmptyState = () => {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-8">
        <div className="text-6xl text-neutral-300 mb-4">
          <i className="fas fa-globe"></i>
        </div>
        <h2 className="text-2xl font-semibold text-neutral-600 mb-2">Welcome to LiteBrowser</h2>
        <p className="text-neutral-500 mb-6 text-center max-w-md">
          A lightweight web browser with offline capability and quick access to your favorite apps.
        </p>
        <div className="flex space-x-4">
          <button className="bg-primary hover:bg-primary-dark text-white py-2 px-4 rounded transition">
            <i className="fas fa-compass mr-2"></i> Start Browsing
          </button>
        </div>
      </div>
    );
  };

  const renderExampleContent = () => {
    return (
      <div className="max-w-3xl mx-auto text-center py-16">
        <h1 className="text-3xl font-bold text-neutral-800 mb-6">Example Domain</h1>
        <p className="text-lg text-neutral-600 mb-8">
          This domain is for use in illustrative examples in documents. You may use this domain in literature without prior coordination or asking for permission.
        </p>
        <p className="text-lg text-neutral-600 mb-8">
          <a href="#" className="text-primary hover:underline">More information...</a>
        </p>
        
        <div className="flex justify-center space-x-4 mt-12">
          <button 
            className="bg-primary hover:bg-primary-dark text-white py-2 px-6 rounded transition duration-200"
            onClick={() => activeTab && saveOffline(activeTab.title, activeTab.url, activeTab.favicon)}
          >
            <i className="fas fa-download mr-2"></i> Save Offline
          </button>
          <button className="border border-neutral-300 hover:border-neutral-400 text-neutral-700 py-2 px-6 rounded transition duration-200">
            <i className="fas fa-share-alt mr-2"></i> Share
          </button>
        </div>
        
        <div className="mt-16 p-6 bg-neutral-100 rounded-lg">
          <h2 className="text-xl font-semibold text-neutral-700 mb-4">LiteBrowser Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
            <div className="p-4">
              <div className="text-primary mb-2"><i className="fas fa-bolt text-2xl"></i></div>
              <h3 className="font-medium text-neutral-800 mb-1">Fast &amp; Lightweight</h3>
              <p className="text-sm text-neutral-600">Optimized performance with minimal resource usage</p>
            </div>
            <div className="p-4">
              <div className="text-primary mb-2"><i className="fas fa-wifi-slash text-2xl"></i></div>
              <h3 className="font-medium text-neutral-800 mb-1">Offline Reading</h3>
              <p className="text-sm text-neutral-600">Save pages for access without internet connection</p>
            </div>
            <div className="p-4">
              <div className="text-primary mb-2"><i className="fas fa-rocket text-2xl"></i></div>
              <h3 className="font-medium text-neutral-800 mb-1">App Integration</h3>
              <p className="text-sm text-neutral-600">Quick access to web and desktop applications</p>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderContent = () => {
    if (!activeTab) return renderEmptyState();
    
    // Default page content (simulating a browser)
    if (activeTab.url === 'about:blank') {
      return renderEmptyState();
    } else if (activeTab.url === 'https://example.com') {
      return renderExampleContent();
    } else {
      // For other URLs, show a loading/unavailable message
      // In a real browser, this would be an iframe or a web view
      return (
        <div className="flex-1 flex flex-col items-center justify-center p-8">
          <div className="text-6xl text-neutral-300 mb-4">
            <i className="fas fa-globe"></i>
          </div>
          <h2 className="text-2xl font-semibold text-neutral-600 mb-2">
            {activeTab.isLoading ? 'Loading...' : 'Page Preview'}
          </h2>
          <p className="text-neutral-500 mb-6 text-center max-w-md">
            {activeTab.isLoading
              ? `Loading ${activeTab.url}`
              : `This is a simulated view of ${activeTab.url}`}
          </p>
          <div className="bg-neutral-100 p-4 rounded text-sm text-neutral-600 w-full max-w-lg">
            <div><strong>URL:</strong> {activeTab.url}</div>
            <div><strong>Title:</strong> {activeTab.title}</div>
            <div><strong>Time:</strong> {formatDate(new Date())}</div>
          </div>
        </div>
      );
    }
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden browser-content">
      {/* Browser Content */}
      <div className="flex-1 overflow-auto p-8 bg-white">
        {renderContent()}
      </div>
      
      {/* Status Bar */}
      <StatusBar 
        isSecure={getSecureStatus(activeTab?.url || '')}
        domain={activeTab?.url ? new URL(activeTab.url).hostname : ''}
        isLoading={activeTab?.isLoading || false}
      />
    </div>
  );
};

export default Content;
